# Pixela
Spatial-based filter applying app.
